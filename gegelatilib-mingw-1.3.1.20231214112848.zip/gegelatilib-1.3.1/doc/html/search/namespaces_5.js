var searchData=
[
  ['learn_0',['Learn',['../namespaceLearn.html',1,'']]],
  ['log_1',['Log',['../namespaceLog.html',1,'']]]
];
