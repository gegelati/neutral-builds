/**
 * Copyright or © or Copr. IETR/INSA - Rennes (2020) :
 *
 * Pierre-Yves Le Rolland-Raumer <plerolla@insa-rennes.fr> (2020)
 *
 * GEGELATI is an open-source reinforcement learning framework for training
 * artificial intelligence based on Tangled Program Graphs (TPGs).
 *
 * This software is governed by the CeCILL-C license under French law and
 * abiding by the rules of distribution of free software. You can use,
 * modify and/ or redistribute the software under the terms of the CeCILL-C
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info".
 *
 * As a counterpart to the access to the source code and rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty and the software's author, the holder of the
 * economic rights, and the successive licensors have only limited
 * liability.
 *
 * In this respect, the user's attention is drawn to the risks associated
 * with loading, using, modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean that it is complicated to manipulate, and that also
 * therefore means that it is reserved for developers and experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or
 * data to be ensured and, more generally, to use and operate it in the
 * same conditions as regards security.
 *
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL-C license and that you accept its terms.
 */

#ifndef ADVERSARIAL_EVALUATION_RESULT_H
#define ADVERSARIAL_EVALUATION_RESULT_H

#include <memory>
#include <stdexcept>
#include <vector>

#include "learn/evaluationResult.h"

namespace Learn {
    /**
     * \brief Class for storing all results of a policy evaluation in
     * in adversarial mode with an AdversarialLearningEnvironment.
     *
     * The main difference with the base EvaluationResult class is that there
     * are several results. Indeed, in adversarial mode there are several roots
     * in a single simulation and, as a consequence, there are several results
     * at the end.
     */
    class AdversarialEvaluationResult : public EvaluationResult
    {
      protected:
        /// The scores of the roots, in the order in which they participated.
        std::vector<double> scores;

      public:
        /**
         * \brief Base constructor of EvaluationResult, allowing to set scores
         * and the number of evaluations.
         *
         * @param[in] res The scores of the roots in the order.
         * @param[in] nbEval The number of evaluations that have been done to
         * get these scores. Default is 1 as we can guess user only did 1
         * iteration.
         */
        AdversarialEvaluationResult(std::initializer_list<double> res,
                                    size_t nbEval = 1)
            : EvaluationResult(*res.begin(), nbEval), scores(res)
        {
        }

        /**
         * \brief Constructor initializing scores as empty.
         *
         * @param[in] size The size of scores i.e. number of evaluated agents.
         * @param[in] nbEval The number of evaluations that have been done to
         * get these scores. Default is 0, as we have no score, we have no eval.
         */
        AdversarialEvaluationResult(size_t size, size_t nbEval = 0)
            : EvaluationResult(0, nbEval), scores(size, 0)
        {
        }

        /**
         * \brief Simple getter of the score of a single root, given its index.
         *
         * @param[in] index The index of the root in the results list.
         * @return The score corresponding to this index.
         */
        double getScoreOf(int index);

        /**
         * \brief Polymorphic addition assignement operator for
         * AdversariEalvaluationResult.
         *
         * \param[in] other The other evaluation result we add to this one.
         * \return This AdversarialEvaluationResult.
         * \throw std::runtime_error in case the other
         * AdversarialEvaluationResult and this have a different typeid or size.
         */
        EvaluationResult& operator+=(const EvaluationResult& other) override;

        /**
         * \brief Division operator for AdversarialEvaluationResult that simply
         * divides all scores contained in the scores vector by divisor.
         *
         * @param[in] divisor The divisor by which we will divide the results.
         * @return This AdversarialEvaluationResult.
         */
        virtual EvaluationResult& operator/=(double divisor);

        /**
         * \brief Returns the mean of the scores, used for example in a simple
         * learning agent as the root will play against itself. In this
         * situation getting the mean of the scores would be relevant.
         *
         * @return The mean of the scores contained in this object.
         */
        double getResult() const override;

        /**
         * \brief Getter fot the size of scores.
         *
         * @return The size of the scores vector.
         */
        size_t getSize() const;
    };
} // namespace Learn

#endif
