var searchData=
[
  ['job_278',['Job',['../classLearn_1_1Job.html#aa91bede3c0b52bb823b93650084914fc',1,'Learn::Job::Job()=delete'],['../classLearn_1_1Job.html#a2508e794ec099786deb0f8fc42cf2d22',1,'Learn::Job::Job(const TPG::TPGVertex *root, uint64_t archiveSeed=0, uint64_t idx=0)'],['../classLearn_1_1Job.html',1,'Learn::Job']]],
  ['json_279',['Json',['../namespaceJson.html',1,'']]]
];
