var searchData=
[
  ['untypedsharedptr_672',['UntypedSharedPtr',['../classData_1_1UntypedSharedPtr.html',1,'Data']]]
];
