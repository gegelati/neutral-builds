var searchData=
[
  ['gegelati_2eh_687',['gegelati.h',['../gegelati_8h.html',1,'']]]
];
