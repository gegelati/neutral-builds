var searchData=
[
  ['bestroot_0',['bestRoot',['../classLearn_1_1LearningAgent.html#ab0de7eb335644ba589f57f91281d315e',1,'Learn::LearningAgent']]],
  ['bestscorelastgen_1',['bestScoreLastGen',['../classLearn_1_1LearningAgent.html#ac80716f526938f2aa458f9a3102c6253',1,'Learn::LearningAgent']]]
];
