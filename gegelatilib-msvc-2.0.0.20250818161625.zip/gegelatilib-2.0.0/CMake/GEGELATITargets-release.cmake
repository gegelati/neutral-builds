#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "GEGELATI::GEGELATI" for configuration "Release"
set_property(TARGET GEGELATI::GEGELATI APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(GEGELATI::GEGELATI PROPERTIES
  IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/GEGELATI.lib"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/GEGELATI.dll"
  )

list(APPEND _cmake_import_check_targets GEGELATI::GEGELATI )
list(APPEND _cmake_import_check_files_for_GEGELATI::GEGELATI "${_IMPORT_PREFIX}/lib/GEGELATI.lib" "${_IMPORT_PREFIX}/bin/GEGELATI.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
