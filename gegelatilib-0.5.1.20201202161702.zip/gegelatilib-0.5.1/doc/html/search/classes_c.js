var searchData=
[
  ['untypedsharedptr_487',['UntypedSharedPtr',['../classData_1_1UntypedSharedPtr.html',1,'Data']]]
];
