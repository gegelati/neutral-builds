var searchData=
[
  ['width_417',['width',['../classData_1_1PrimitiveTypeArray2D.html#af35f0f78d1aa8472ace50a3a2e0075b7',1,'Data::PrimitiveTypeArray2D']]]
];
