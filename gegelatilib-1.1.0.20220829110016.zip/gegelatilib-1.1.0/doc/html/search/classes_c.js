var searchData=
[
  ['untypedsharedptr_671',['UntypedSharedPtr',['../classData_1_1UntypedSharedPtr.html',1,'Data']]]
];
