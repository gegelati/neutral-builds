var searchData=
[
  ['gegelati_2eh_686',['gegelati.h',['../gegelati_8h.html',1,'']]]
];
