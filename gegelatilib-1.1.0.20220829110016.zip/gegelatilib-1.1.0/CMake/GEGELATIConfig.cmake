set(GEGELATI_VERSION 1.1.0)


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was GEGELATIConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

####################################################################################



if(NOT TARGET GEGELATI::GEGELATI)
  include("${CMAKE_CURRENT_LIST_DIR}/GEGELATITargets.cmake")
endif()

# Compatibility
get_property(GEGELATI_GEGELATI_INCLUDE_DIR TARGET GEGELATI::GEGELATI PROPERTY INTERFACE_INCLUDE_DIRECTORIES)

set(GEGELATI_LIBRARIES GEGELATI::GEGELATI)
set(GEGELATI_INCLUDE_DIRS "${GEGELATI_GEGELATI_INCLUDE_DIR}")
list(REMOVE_DUPLICATES GEGELATI_INCLUDE_DIRS)


