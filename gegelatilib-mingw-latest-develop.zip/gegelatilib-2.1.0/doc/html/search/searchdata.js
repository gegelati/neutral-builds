var indexSectionsWithContent =
{
  0: "_abcdefghijklmnoprstuvw~",
  1: "acdeijlmprstu",
  2: "cdfijlmpstu",
  3: "g",
  4: "acdefghijklmnoprstuvw~",
  5: "_abcdefghilmnoprstuvw",
  6: "eilmpst",
  7: "gl",
  8: "os"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Friends"
};

