var searchData=
[
  ['uniqueless_0',['UniqueLess',['../structUniqueLess.html',1,'']]],
  ['untypedsharedptr_1',['UntypedSharedPtr',['../classData_1_1UntypedSharedPtr.html',1,'Data']]]
];
