var searchData=
[
  ['selector_0',['Selector',['../namespaceSelector.html',1,'']]]
];
