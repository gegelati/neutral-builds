var searchData=
[
  ['_5fselectionmode_0',['_selectionMode',['../structSelector_1_1SelectionParameters.html#aee94a117df4b1a7b67197245961f4a19',1,'Selector::SelectionParameters']]]
];
