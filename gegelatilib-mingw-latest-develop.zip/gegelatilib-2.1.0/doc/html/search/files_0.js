var searchData=
[
  ['gegelati_2eh_0',['gegelati.h',['../gegelati_8h.html',1,'']]]
];
