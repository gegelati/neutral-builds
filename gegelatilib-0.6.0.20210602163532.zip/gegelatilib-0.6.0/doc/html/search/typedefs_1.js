var searchData=
[
  ['learningmode_1013',['LearningMode',['../namespaceLearn.html#a1b4cb7b05b066cbd5bfdd0fa30049e61',1,'Learn']]],
  ['learningparameters_1014',['LearningParameters',['../namespaceLearn.html#aa3a829d2a797552568b1231b1d37275b',1,'Learn']]]
];
