var searchData=
[
  ['data_63',['Data',['../namespaceData.html',1,'']]],
  ['data_64',['data',['../classData_1_1PrimitiveTypeArray.html#a558232cb888f98fcc4e14abb53b5e774',1,'Data::PrimitiveTypeArray']]],
  ['datahandler_65',['DataHandler',['../classData_1_1DataHandler.html',1,'Data::DataHandler'],['../classData_1_1DataHandler.html#a56a28204ab91703ef1c4ef583cea26f5',1,'Data::DataHandler::DataHandler()'],['../classData_1_1DataHandler.html#aee350c02ec8afb063da81f95ac43137a',1,'Data::DataHandler::DataHandler(const DataHandler &amp;other)=default']]],
  ['datahandlers_66',['dataHandlers',['../classArchive.html#a416bef3d78b8366a15ccc180326e68e6',1,'Archive']]],
  ['datahash_67',['dataHash',['../structArchiveRecording.html#a992adfd8275ba543c3f7eb9742692f15',1,'ArchiveRecording']]],
  ['datascsconstsandregs_68',['dataScsConstsAndRegs',['../classProgram_1_1ProgramExecutionEngine.html#a5c5922980aa7cb5df5fd0c8d96a63332',1,'Program::ProgramExecutionEngine']]],
  ['datasources_69',['dataSources',['../classEnvironment.html#a4713368e4a7e818b006c8d888fcb5dcb',1,'Environment::dataSources()'],['../classProgram_1_1ProgramExecutionEngine.html#abda1104c15fc82fb5737dac5253dd699',1,'Program::ProgramExecutionEngine::dataSources()']]],
  ['decimateworstroots_70',['decimateWorstRoots',['../classLearn_1_1ClassificationLearningAgent.html#a58f43b9ee614b29ec4146905520d9205',1,'Learn::ClassificationLearningAgent::decimateWorstRoots()'],['../classLearn_1_1LearningAgent.html#a9d0f3cdc7cad21d5e88f6cf57ce7ce9b',1,'Learn::LearningAgent::decimateWorstRoots()']]],
  ['deleterandomline_71',['deleteRandomLine',['../namespaceMutator_1_1ProgramMutator.html#a937013c8c3903ec830bdb9daa7bb9b41',1,'Mutator::ProgramMutator']]],
  ['destination_72',['destination',['../classTPG_1_1TPGEdge.html#a6398bf000e4b1ae5b1b6d753a79ca852',1,'TPG::TPGEdge']]],
  ['destinationindex_73',['destinationIndex',['../classProgram_1_1Line.html#a0c13efb201ecd2b2ee58aa7686f4cfe8',1,'Program::Line']]],
  ['doaction_74',['doAction',['../classLearn_1_1ClassificationLearningEnvironment.html#a10a23c4c74fb8d9b9585846fb6b32cf6',1,'Learn::ClassificationLearningEnvironment::doAction()'],['../classLearn_1_1LearningEnvironment.html#aa797b5ad490d78ef32fa34fdd878a9bb',1,'Learn::LearningEnvironment::doAction()']]],
  ['dovalidation_75',['doValidation',['../structLearn_1_1LearningParameters.html#af00afb5f5b2aae83ba427c862cc93965',1,'Learn::LearningParameters::doValidation()'],['../classLog_1_1LALogger.html#adb2be54a06a0ce1b794f59064657d054',1,'Log::LALogger::doValidation()']]],
  ['dovalidationcomment_76',['doValidationComment',['../structLearn_1_1LearningParameters.html#ad172de66f1c0eede954e522a8dd1623d',1,'Learn::LearningParameters']]],
  ['dumptpggraphheader_77',['dumpTPGGraphHeader',['../classFile_1_1TPGGraphDotImporter.html#ab293ee6fdb3d08e8ae28db1d107f2a74',1,'File::TPGGraphDotImporter']]]
];
