var searchData=
[
  ['gegelati_2eh_691',['gegelati.h',['../gegelati_8h.html',1,'']]]
];
