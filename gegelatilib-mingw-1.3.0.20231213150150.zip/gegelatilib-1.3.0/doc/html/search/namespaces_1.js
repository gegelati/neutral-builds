var searchData=
[
  ['data_0',['Data',['../namespaceData.html',1,'']]]
];
