var searchData=
[
  ['untypedsharedptr_0',['UntypedSharedPtr',['../classData_1_1UntypedSharedPtr.html',1,'Data']]]
];
